(function() {
	'use strict';

	angular
		.module('restaurant.login', [
			'ionic'
		])
})();