(function() {
	'use strict';

	angular
		.module('restaurant.restaurant-delivery')
		.controller('DeliveryMethodSelectorController', DeliveryMethodSelectorController);

	DeliveryMethodSelectorController.$inject = [];

	/* @ngInject */
	function DeliveryMethodSelectorController() {
		var vm = angular.extend(this, {
		});

		(function activate() {
		})();

		// ********************************************************************
	}
})();
