"use strict";

 angular.module('config', [])

.constant('ENV', {name:'development',dataProvider:'FIREBASE',firebaseConfig:{apiKey:'AIzaSyBrdY5tKX1_oIfLiN8O8VCSViCpjchnBG0',authDomain:'restaurant-backend-bd335.firebaseapp.com',databaseURL:'https://restaurant-backend-bd335.firebaseio.com'},youtubeKey:'AIzaSyDael5MmCQa1GKQNKQYypmBeB08GATgSEo',facebookAppId:'',googleAppId:'',ionicCloudApiToken:'',ionicSecurityProfile:'',ionicAppId:'ab64f538',gcmId:'228071472080'})

;